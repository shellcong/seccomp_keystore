package com.example.keystore;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.security.KeyPairGeneratorSpec;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;
import java.util.Calendar;
import java.util.Enumeration;

import javax.security.auth.x500.X500Principal;





public class MainActivity extends Activity {


	
	public class KeyStorage {

		public static final String ANDROID_KEYSTORE = "AndroidKeyStore";

		public void loadKeyStore() {
		    try {
		        KeyStore ks = KeyStore.getInstance(ANDROID_KEYSTORE);
		        ks.load(null);
		        Enumeration<String> aliases = ks.aliases();
		        while(aliases.hasMoreElements())
		            Log.d("log", "Aliases = " + aliases.nextElement());
		        
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		    
		    
		}

		public void generateNewKeyPair(String alias, Context context)
		        throws Exception {

		    Calendar start = Calendar.getInstance();
		    Calendar end = Calendar.getInstance();
		    // expires 1 year from today
		    end.add(1, Calendar.YEAR);

		 
		    KeyPairGeneratorSpec spec = new KeyPairGeneratorSpec.Builder(context)
		            .setAlias(alias)
		            .setSubject(new X500Principal("CN=" + alias))
		            .setSerialNumber(BigInteger.TEN)
		            .setStartDate(start.getTime())
		            .setEndDate(end.getTime())
		            .build();

		    // use the Android keystore
		    KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA", ANDROID_KEYSTORE);
		    gen.initialize(spec);

		    // generates the keypair
		    KeyPair kp = gen.generateKeyPair();
		    Log.i("log", "gen succeed");
		    Log.i("log", "Public Key is: " + kp.getPublic().toString());
		    Log.i("log", "Private Key is: " + kp.getPrivate().toString());
		}

		public PrivateKey loadPrivteKey(String alias) throws Exception {

			KeyStore ks = KeyStore.getInstance(ANDROID_KEYSTORE);
			ks.load(null);
			
			KeyStore.Entry entry = ks.getEntry(alias, null);
			
			if (entry == null){
				Log.w("error", "No key found under alias: " + alias);
				return null;
			}
			
			if (!(entry instanceof KeyStore.PrivateKeyEntry)) {
	            Log.w("error", "Not an instance of a PrivateKeyEntry");
	            Log.w("error", "Exiting signData()...");
	            return null;
	        }
			Log.d("log", "find private key");
			Log.d("log", ((KeyStore.PrivateKeyEntry) entry).getPrivateKey().toString());
		    return ((KeyStore.PrivateKeyEntry) entry).getPrivateKey();
		}		
	}
	
	
	
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		KeyStorage keystorage = new KeyStorage();
		//keystorage.loadKeyStore();
		try {
			//keystorage.generateNewKeyPair("aa",this);
			keystorage.generateNewKeyPair("bb",this);
			//keystorage.generateNewKeyPair("cc",this);

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			keystorage.loadPrivteKey("bb");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
